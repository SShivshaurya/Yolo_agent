
import numpy as np
import cv2
import onnxruntime as ort

def nms(dets, iou_threshold=0.5):
    if len(dets)==0: return []
    boxes=np.array([d['bbox'] for d in dets],float)
    scores=np.array([d['conf'] for d in dets],float)
    x1,y1,x2,y2=boxes[:,0],boxes[:,1],boxes[:,2],boxes[:,3]
    areas=(x2-x1)*(y2-y1)
    order=scores.argsort()[::-1]
    keep=[]
    while order.size>0:
        i=order[0]; keep.append(i)
        xx1=np.maximum(x1[i],x1[order[1:]])
        yy1=np.maximum(y1[i],y1[order[1:]])
        xx2=np.minimum(x2[i],x2[order[1:]])
        yy2=np.minimum(y2[i],y2[order[1:]])
        w=np.maximum(0,xx2-xx1); h=np.maximum(0,yy2-yy1)
        inter=w*h
        iou=inter/(areas[i]+areas[order[1:]]-inter+1e-9)
        order=order[1:][iou< iou_threshold]
    return [dets[i] for i in keep]

class ModelWrapper:
    def __init__(self, model_path, img_size=(640,640), conf_thresh=0.25, use_nms=True):
        self.session=ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])
        self.img_size=img_size
        self.conf_thresh=conf_thresh
        self.use_nms=use_nms

    def _preprocess(self, path):
        img=cv2.imread(path)
        img=cv2.resize(img,self.img_size[::-1])
        img=cv2.cvtColor(img, cv2.COLOR_BGR2RGB)/255.0
        img=np.transpose(img,(2,0,1))[None].astype('float32')
        return img

    def _postprocess(self, out):
        # out is (1, 6, N)
        out=out[0]
        x1,y1,x2,y2,conf,cls = out
        dets=[]
        for i in range(len(x1)):
            c=float(conf[i])
            if c<self.conf_thresh: continue
            dets.append({
                'cls':str(int(cls[i])),
                'bbox':[float(x1[i]),float(y1[i]),float(x2[i]),float(y2[i])],
                'conf':c
            })
        return nms(dets) if self.use_nms else dets

    def predict(self, img_path):
        inp=self._preprocess(img_path)
        name=self.session.get_inputs()[0].name
        out=self.session.run(None,{name:inp})
        return self._postprocess(out[0])
