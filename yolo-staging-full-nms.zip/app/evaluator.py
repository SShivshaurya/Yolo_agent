
from .utils import match_detections

def compute_map(preds,gts,classes):
    results={}
    for c in classes:
        results[c] = _compute_for_class(preds,gts,c)
    map50 = sum([results[c]['ap'] for c in results]) / max(1,len(results))
    return {'per_class': results, 'map_50': map50}

def _compute_for_class(preds,gts,c):
    scores=[]; truths=[]
    total_gts=sum([len([g for g in gg if g.get('cls')==c]) for gg in gts])
    for p,gg in zip(preds,gts):
        pc=[x for x in p if x.get('cls')==c]
        gc=[x for x in gg if x.get('cls')==c]
        matches,fns=match_detections(pc,gc,0.5)
        for (pd,gt,_iou) in matches:
            scores.append(pd['conf']); truths.append(1 if gt else 0)
    if not scores:
        return {'ap':0,'precision':0,'recall':0}
    order=sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
    tp=0; fp=0; prec=[]; rec=[]
    for i in order:
        if truths[i]==1: tp+=1
        else: fp+=1
        prec.append(tp/(tp+fp)); rec.append(tp/(total_gts+1e-9))
    ap=0; prev=0
    for p,r in zip(prec,rec):
        ap += p*(r-prev); prev=r
    return {'ap':ap, 'precision':prec[-1], 'recall':rec[-1]}
