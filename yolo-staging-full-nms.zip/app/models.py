
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, JSON
import datetime

Base = declarative_base()

class ModelEntry(Base):
    __tablename__='models'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    version = Column(String)
    path = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class DatasetEntry(Base):
    __tablename__='datasets'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    path = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class EvalRun(Base):
    __tablename__='evaluations'
    id = Column(Integer, primary_key=True)
    model_id = Column(Integer)
    dataset_id = Column(Integer)
    metrics = Column(JSON)
    json_path = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class DriftEntry(Base):
    __tablename__='drifts'
    id = Column(Integer, primary_key=True)
    prev_model_id = Column(Integer)
    curr_model_id = Column(Integer)
    dataset_id = Column(Integer)
    drift = Column(String)
    json_path = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
