
# YOLO Staging Server (Full Version with NMS)
This is the complete non-docker YOLO model staging server, now updated with
correct ONNX output parsing and IoU-based NMS.

Includes:
- Model upload
- Dataset upload
- Evaluation (mAP)
- Model comparison (drift)
- JSON saving to evaluations/
- Frontend dashboard with Chart.js
- NMS-enabled inference
