YOLO Staging Server — Full (Drift images, Dynamic Inference)
===========================================================

This repository is a local, non-docker staging server that supports:
- model upload (.onnx)
- dataset upload (zip with images/ and labels/ in YOLO txt-like format)
- evaluation (mAP@0.5 simplified)
- model comparison (delta mAP) + automatic generation of drift images (prev/curr/overlay)
- frontend dashboard to upload, evaluate, compare and preview drift images
- dynamic ONNX inference parser that adapts to various output shapes (single/multi-class, channel-first/last)

Run:
  python -m venv venv
  source venv/bin/activate   # or venv\Scripts\activate on Windows
  pip install -r requirements.txt
  python app/main.py

Open: http://localhost:8000/static/index.html
