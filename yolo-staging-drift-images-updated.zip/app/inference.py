
import numpy as np
import cv2
import onnxruntime as ort

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def nms(dets, iou_threshold=0.5, max_det=300):
    if not dets:
        return []
    boxes = np.array([d['bbox'] for d in dets], dtype=np.float32)
    scores = np.array([d['conf'] for d in dets], dtype=np.float32)
    classes = np.array([int(d['cls']) for d in dets], dtype=np.int32)
    keep_all = []
    unique_classes = np.unique(classes)
    for cls in unique_classes:
        idxs = np.where(classes == cls)[0]
        cls_boxes = boxes[idxs]
        cls_scores = scores[idxs]
        order = cls_scores.argsort()[::-1]
        while order.size > 0:
            i = order[0]
            keep_all.append(idxs[i])
            if order.size == 1:
                break
            xx1 = np.maximum(cls_boxes[i, 0], cls_boxes[order[1:], 0])
            yy1 = np.maximum(cls_boxes[i, 1], cls_boxes[order[1:], 1])
            xx2 = np.minimum(cls_boxes[i, 2], cls_boxes[order[1:], 2])
            yy2 = np.minimum(cls_boxes[i, 3], cls_boxes[order[1:], 3])
            w = np.maximum(0.0, xx2 - xx1)
            h = np.maximum(0.0, yy2 - yy1)
            inter = w * h
            area_i = (cls_boxes[i, 2] - cls_boxes[i, 0]) * (cls_boxes[i, 3] - cls_boxes[i, 1])
            area_rest = (cls_boxes[order[1:], 2] - cls_boxes[order[1:], 0]) * (cls_boxes[order[1:], 3] - cls_boxes[order[1:], 1])
            iou = inter / (area_i + area_rest - inter + 1e-9)
            remaining = np.where(iou < iou_threshold)[0]
            order = order[remaining + 1]
    keep_all = list(dict.fromkeys(keep_all))
    keep_all = sorted(keep_all, key=lambda i: scores[i], reverse=True)[:max_det]
    return [dets[i] for i in keep_all]

class ModelWrapper:
    def __init__(self, model_path, img_size=(640,640), conf_thresh=0.25, iou_thresh=0.5, use_nms=True, providers=None, box_format='auto'):
        providers = providers or ['CPUExecutionProvider']
        self.session = ort.InferenceSession(model_path, providers=providers)
        self.img_size = tuple(img_size)
        self.conf_thresh = float(conf_thresh)
        self.iou_thresh = float(iou_thresh)
        self.use_nms = bool(use_nms)
        self.box_format = box_format

    def _preprocess(self, image_path):
        img = cv2.imread(image_path)
        if img is None:
            raise FileNotFoundError(image_path)
        orig_h, orig_w = img.shape[:2]
        target_h, target_w = self.img_size
        resized = cv2.resize(img, (target_w, target_h))
        inp = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB).astype('float32') / 255.0
        inp = np.transpose(inp, (2,0,1))[None, ...].astype('float32')
        return inp, (orig_w, orig_h), img

    def _detect_layout(self, out_arr):
        shape = out_arr.shape
        if len(shape) != 3:
            raise ValueError("Unexpected model output shape: %s" % (shape,))
        b, a, c = shape
        if a <= 256:
            channel_first = True
            C = a
            N = c
        else:
            channel_first = False
            C = c
            N = a
        return channel_first, C, N

    def _postprocess_dynamic(self, raw_out, orig_size):
        channel_first, C, N = self._detect_layout(raw_out)
        if channel_first:
            arr = raw_out[0]
        else:
            arr = raw_out[0].T
        C_dim = arr.shape[0]
        if C_dim < 6:
            raise ValueError(f"Unsupported channels: {C_dim}")
        x1 = arr[0]; y1 = arr[1]; x2 = arr[2]; y2 = arr[3]; fifth = arr[4]; rest = arr[5:]
        cls_is_id = False
        if rest.shape[0] == 1:
            cls_channel = rest[0]
            is_int_like = np.all(np.isclose(cls_channel, np.round(cls_channel), atol=1e-3))
            if is_int_like:
                cls_is_id = True
        dets = []
        if (not cls_is_id) and rest.shape[0] >= 2:
            obj = sigmoid(fifth)
            cls_logits = rest
            cls_scores = sigmoid(cls_logits)
            final = cls_scores * obj[np.newaxis, :]
            best_cls = np.argmax(final, axis=0)
            best_conf = final[best_cls, np.arange(final.shape[1])]
            for i in range(final.shape[1]):
                conf = float(best_conf[i])
                if conf < self.conf_thresh: continue
                cls_id = int(best_cls[i])
                bx1 = float(x1[i]); by1 = float(y1[i]); bx2 = float(x2[i]); by2 = float(y2[i])
                dets.append({'cls': cls_id, 'conf': conf, 'bbox': [bx1, by1, bx2, by2]})
        else:
            obj_or_conf = fifth
            if rest.shape[0] == 1:
                cls_channel = rest[0]
                is_int_like = np.all(np.isclose(cls_channel, np.round(cls_channel), atol=1e-3))
                if is_int_like:
                    for i in range(cls_channel.shape[0]):
                        conf = float(obj_or_conf[i])
                        if conf < self.conf_thresh: continue
                        cls_id = int(round(cls_channel[i]))
                        bx1 = float(x1[i]); by1 = float(y1[i]); bx2 = float(x2[i]); by2 = float(y2[i])
                        dets.append({'cls': cls_id, 'conf': conf, 'bbox': [bx1, by1, bx2, by2]})
                else:
                    obj = sigmoid(obj_or_conf)
                    cls_score = sigmoid(cls_channel)
                    final_conf = obj * cls_score
                    for i in range(final_conf.shape[0]):
                        conf = float(final_conf[i])
                        if conf < self.conf_thresh: continue
                        cls_id = int(round(cls_channel[i])) if np.isclose(round(cls_channel[i]), cls_channel[i], atol=1e-3) else 0
                        bx1 = float(x1[i]); by1 = float(y1[i]); bx2 = float(x2[i]); by2 = float(y2[i])
                        dets.append({'cls': cls_id, 'conf': conf, 'bbox': [bx1, by1, bx2, by2]})
            else:
                obj = sigmoid(obj_or_conf)
                for i in range(obj.shape[0]):
                    conf = float(obj[i])
                    if conf < self.conf_thresh: continue
                    cls_id = 0
                    bx1 = float(x1[i]); by1 = float(y1[i]); bx2 = float(x2[i]); by2 = float(y2[i])
                    dets.append({'cls': cls_id, 'conf': conf, 'bbox': [bx1, by1, bx2, by2]})
        if len(dets) > 0:
            bbox_array = np.array([d['bbox'] for d in dets], dtype=np.float32)
            mean_width = np.mean(bbox_array[:, 2] - bbox_array[:, 0])
            if mean_width <= 0 and self.box_format == 'auto':
                for d in dets:
                    cx, cy, w, h = d['bbox']
                    x1c = cx - w/2.0; y1c = cy - h/2.0; x2c = cx + w/2.0; y2c = cy + h/2.0
                    d['bbox'] = [x1c, y1c, x2c, y2c]
        orig_w, orig_h = orig_size
        if dets:
            max_coord = max([max(map(abs, d['bbox'])) for d in dets])
            if max_coord <= 1.0 + 1e-6:
                for d in dets:
                    x1,y1,x2,y2 = d['bbox']
                    d['bbox'] = [x1 * orig_w, y1 * orig_h, x2 * orig_w, y2 * orig_h]
        if self.use_nms:
            dets = nms(dets, iou_threshold=self.iou_thresh)
        return dets

    def predict(self, image_path):
        inp, orig_size, _ = self._preprocess(image_path)
        name = self.session.get_inputs()[0].name
        outs = self.session.run(None, {name: inp})
        raw_out = outs[0]
        dets = self._postprocess_dynamic(raw_out, orig_size)
        return dets
