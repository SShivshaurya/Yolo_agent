import os, zipfile, uuid, json, time
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from .db import init_db, get_db
from .models import Base, ModelEntry, DatasetEntry, EvalRun, DriftEntry
from .inference import ModelWrapper
from .evaluator import compute_map
from .utils import iou
from sqlalchemy.orm import Session
from .db import SessionLocal

app = FastAPI(title='YOLO Staging Server with Drift Images')
app.mount('/static', StaticFiles(directory='static'), name='static')
app.mount('/drift_images', StaticFiles(directory='drift_images'), name='drift_images')

DATA_DIR = './data'
EVAL_DIR = './evaluations'
DRIFT_DIR = './drift_images'
os.makedirs(DATA_DIR, exist_ok=True); os.makedirs(EVAL_DIR, exist_ok=True); os.makedirs(DRIFT_DIR, exist_ok=True)
init_db(Base)

def get_session():
    s = SessionLocal();
    try: yield s
    finally: s.close()

@app.get('/')
def root():
    return {'status':'ok'}

@app.post('/models/upload')
async def upload_model(name: str = Form(...), version: str = Form(...), file: UploadFile = File(...), db: Session = Depends(get_session)):
    contents = await file.read()
    mdir = os.path.join(DATA_DIR, 'models'); os.makedirs(mdir, exist_ok=True)
    fname = f"{name}__{version}__{uuid.uuid4().hex}{Path(file.filename).suffix}"
    path = os.path.join(mdir, fname)
    with open(path, 'wb') as f: f.write(contents)
    rec = ModelEntry(name=name, version=version, path=path)
    db.add(rec); db.commit(); db.refresh(rec)
    return {'id': rec.id, 'name': rec.name, 'version': rec.version}

@app.post('/datasets/upload')
async def upload_dataset(name: str = Form(...), file: UploadFile = File(...), db: Session = Depends(get_session)):
    contents = await file.read()
    ddir = os.path.join(DATA_DIR, 'datasets', uuid.uuid4().hex); os.makedirs(ddir, exist_ok=True)
    zpath = os.path.join(ddir, file.filename)
    with open(zpath, 'wb') as f: f.write(contents)
    try:
        with zipfile.ZipFile(zpath, 'r') as z: z.extractall(ddir)
    except Exception:
        pass
    rec = DatasetEntry(name=name, path=ddir)
    db.add(rec); db.commit(); db.refresh(rec)
    return {'id': rec.id, 'name': rec.name}

@app.get('/list/models')
def list_models(db: Session = Depends(get_session)):
    recs = db.query(ModelEntry).all()
    return [{'id': r.id, 'name': r.name, 'version': r.version} for r in recs]

@app.get('/list/datasets')
def list_datasets(db: Session = Depends(get_session)):
    recs = db.query(DatasetEntry).all()
    return [{'id': r.id, 'name': r.name} for r in recs]

def draw_boxes(img_path, dets, color):
    import cv2
    img = cv2.imread(img_path)
    if img is None: return None
    for d in dets:
        x1,y1,x2,y2 = map(int, d['bbox'])
        label = f"{d.get('cls')}:{d.get('conf'):.2f}"
        cv2.rectangle(img, (x1,y1), (x2,y2), color, 2)
        cv2.putText(img, label, (x1, max(0,y1-6)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
    return img

@app.post('/evaluate')
def evaluate(model_id: int, dataset_id: int, db: Session = Depends(get_session)):
    model = db.query(ModelEntry).get(model_id)
    dataset = db.query(DatasetEntry).get(dataset_id)
    if not model or not dataset: raise HTTPException(status_code=404, detail='model/dataset not found')
    mw = ModelWrapper(model.path)
    img_folder = os.path.join(dataset.path, 'images')
    if not os.path.exists(img_folder): img_folder = dataset.path
    imgs = list(Path(img_folder).glob('**/*'))
    preds=[]; gts=[]; classes=set()
    for p in imgs:
        if p.suffix.lower() not in ['.jpg','.jpeg','.png']: continue
        try: dets = mw.predict(str(p))
        except Exception:
            dets = []
        preds.append(dets)
        lab = Path(dataset.path)/'labels'/(p.stem+'.txt')
        gt=[]
        if lab.exists():
            for line in open(lab):
                toks=line.strip().split();
                if len(toks)>=5:
                    cls=toks[0]; x1,y1,x2,y2=map(float,toks[1:5]); gt.append({'cls':cls,'bbox':[x1,y1,x2,y2]}); classes.add(cls)
        gts.append(gt)
    metrics = compute_map(preds, gts, list(classes))
    ts = int(time.time()); fname=f'evaluation_model_{model.id}_ds_{dataset.id}_{ts}.json'; fpath=os.path.join(EVAL_DIR,fname)
    with open(fpath,'w') as ef: json.dump({'model':{'id':model.id,'name':model.name,'version':model.version}, 'dataset':{'id':dataset.id,'path':dataset.path}, 'metrics':metrics}, ef, indent=2)
    er = EvalRun(model_id=model.id, dataset_id=dataset.id, metrics=metrics, json_path=fpath)
    db.add(er); db.commit(); db.refresh(er)
    return {'eval_id': er.id, 'metrics': metrics, 'json': fpath}

@app.post('/compare')
def compare(prev_model: int, curr_model: int, dataset_id: int, db: Session = Depends(get_session)):
    pm = db.query(ModelEntry).get(prev_model)
    cm = db.query(ModelEntry).get(curr_model)
    ds = db.query(DatasetEntry).get(dataset_id)
    if not pm or not cm or not ds: raise HTTPException(status_code=404, detail='missing')
    mw_prev = ModelWrapper(pm.path); mw_curr = ModelWrapper(cm.path)
    img_folder = os.path.join(ds.path, 'images')
    if not os.path.exists(img_folder): img_folder = ds.path
    imgs = list(Path(img_folder).glob('**/*'))
    preds_prev=[]; preds_curr=[]; gts=[]; classes=set()
    drift_images = []
    drift_subdir = f"{pm.id}_vs_{cm.id}_{int(time.time())}"
    save_dir = os.path.join(DRIFT_DIR, drift_subdir); os.makedirs(save_dir, exist_ok=True)
    for p in imgs:
        if p.suffix.lower() not in ['.jpg','.jpeg','.png']: continue
        try: dp = mw_prev.predict(str(p))
        except: dp = []
        try: dc = mw_curr.predict(str(p))
        except: dc = []
        preds_prev.append(dp); preds_curr.append(dc)
        lab = Path(ds.path)/'labels'/(p.stem+'.txt')
        gt=[]
        if lab.exists():
            for line in open(lab):
                toks=line.strip().split(); cls=toks[0]; x1,y1,x2,y2=map(float,toks[1:5]); gt.append({'cls':cls,'bbox':[x1,y1,x2,y2]}); classes.add(cls)
        gts.append(gt)
        sig = False
        if len(dp) != len(dc): sig = True
        else:
            for a in dp:
                best=0
                for b in dc:
                    if a.get('cls')!=b.get('cls'): continue
                    best = max(best, iou(a['bbox'], b['bbox']))
                if best < 0.5:
                    sig = True; break
        if sig:
            img_prev = draw_boxes(str(p), dp, (0,0,255))
            img_curr = draw_boxes(str(p), dc, (0,255,0))
            if img_prev is None or img_curr is None: continue
            overlay = cv2.addWeighted(img_prev, 0.6, img_curr, 0.4, 0)
            base = p.name
            prev_path = os.path.join(save_dir, base.replace('.', '_prev.')) + 'jpg'
            curr_path = os.path.join(save_dir, base.replace('.', '_curr.')) + 'jpg'
            over_path = os.path.join(save_dir, base.replace('.', '_overlay.')) + 'jpg'
            import cv2
            cv2.imwrite(prev_path, img_prev)
            cv2.imwrite(curr_path, img_curr)
            cv2.imwrite(over_path, overlay)
            drift_images.append({'image': p.name, 'prev': f'/drift_images/{drift_subdir}/'+os.path.basename(prev_path), 'curr': f'/drift_images/{drift_subdir}/'+os.path.basename(curr_path), 'overlay': f'/drift_images/{drift_subdir}/'+os.path.basename(over_path)})
    mprev = compute_map(preds_prev, gts, list(classes))
    mcurr = compute_map(preds_curr, gts, list(classes))
    delta = mcurr.get('map_50',0.0) - mprev.get('map_50',0.0)
    fname = f'compare_{pm.id}_{cm.id}_{int(time.time())}.json'
    fpath = os.path.join(EVAL_DIR, fname)
    with open(fpath,'w') as ef: json.dump({'prev':mprev,'curr':mcurr,'delta':delta,'drift_images':drift_images}, ef, indent=2)
    dr = DriftEntry(prev_model_id=pm.id, curr_model_id=cm.id, dataset_id=ds.id, drift=str(delta), json_path=fpath)
    db.add(dr); db.commit(); db.refresh(dr)
    return {'prev': mprev, 'curr': mcurr, 'delta': delta, 'drift_images': drift_images, 'json': fpath}

@app.get('/evaluations/list')
def list_evals():
    files = [f for f in os.listdir(EVAL_DIR) if f.endswith('.json')]
    return files

@app.get('/evaluations/get')
def get_eval(path: str):
    p = os.path.join(EVAL_DIR, path)
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail='not found')
    return json.load(open(p))

@app.get('/drift_images/list')
def list_drift_folders():
    out = []
    for name in os.listdir(DRIFT_DIR):
        p = os.path.join(DRIFT_DIR, name)
        if os.path.isdir(p):
            imgs = [f for f in os.listdir(p) if f.lower().endswith('.jpg')]
            out.append({'folder': name, 'count': len(imgs)})
    return out

@app.get('/drift_images/get')
def get_drift(folder: str):
    p = os.path.join(DRIFT_DIR, folder)
    if not os.path.exists(p): raise HTTPException(status_code=404)
    imgs = [f for f in os.listdir(p) if f.lower().endswith('.jpg')]
    return {'folder': folder, 'images': imgs}
