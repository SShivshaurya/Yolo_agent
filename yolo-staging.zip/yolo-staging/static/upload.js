async function uploadModel(formId='fm_model'){
  const form = document.getElementById(formId);
  const fd = new FormData(form);
  const res = await fetch('/models/upload', {method:'POST', body: fd});
  const txt = await res.text();
  alert('Upload response: ' + txt);
}

async function uploadDataset(formId='fm_data'){
  const form = document.getElementById(formId);
  const fd = new FormData(form);
  const res = await fetch('/datasets/upload', {method:'POST', body: fd});
  const txt = await res.text();
  alert('Upload response: ' + txt);
}

async function evaluate(){
  const model_id = prompt('Enter model_id to evaluate:');
  const dataset_id = prompt('Enter dataset_id:');
  const res = await fetch(`/evaluate?model_id=${model_id}&dataset_id=${dataset_id}`, {method:'POST'});
  const json = await res.json();
  alert('Evaluation result:\n' + JSON.stringify(json, null, 2));
}

async function compare(){
  const prev = prompt('prev_model_id:');
  const curr = prompt('curr_model_id:');
  const ds = prompt('dataset_id:');
  const res = await fetch(`/compare?prev_model=${prev}&curr_model=${curr}&dataset_id=${ds}`, {method:'POST'});
  const json = await res.json();
  alert('Compare result:\n' + JSON.stringify(json, null, 2));
}
