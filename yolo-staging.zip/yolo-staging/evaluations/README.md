# Evaluations

JSON evaluation outputs from the /evaluate and /compare endpoints.
