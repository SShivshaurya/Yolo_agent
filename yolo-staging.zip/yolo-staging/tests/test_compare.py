def test_placeholder_compare():
    assert True
