def test_placeholder_inference():
    assert True
