import numpy as np
def iou(a,b):
    xA=max(a[0],b[0]); yA=max(a[1],b[1])
    xB=min(a[2],b[2]); yB=min(a[3],b[3])
    interW=max(0,xB-xA); interH=max(0,yB-yA)
    interArea=interW*interH
    areaA=max(0,(a[2]-a[0])*(a[3]-a[1]))
    areaB=max(0,(b[2]-b[0])*(b[3]-b[1]))
    return interArea/(areaA+areaB-interArea+1e-9)
def match_detections(preds,gts,th=0.5):
    used=set(); matches=[]
    preds_sorted = sorted(preds, key=lambda x: x.get('conf',0), reverse=True)
    for p in preds_sorted:
        best=0; idx=None
        for i,g in enumerate(gts):
            if i in used: continue
            if p.get('cls') != g.get('cls'): continue
            v=iou(p['bbox'], g['bbox'])
            if v>best: best=v; idx=i
        if best>=th:
            matches.append((p,gts[idx],best)); used.add(idx)
        else:
            matches.append((p,None,best))
    fns=[g for i,g in enumerate(gts) if i not in used]
    return matches, fns
