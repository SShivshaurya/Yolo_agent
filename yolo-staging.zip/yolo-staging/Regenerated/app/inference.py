import onnxruntime as ort
import numpy as np, cv2
class ModelWrapper:
    def __init__(self, model_path, img_size=(640,640), conf_thresh=0.25):
        self.model_path = model_path
        self.session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])
        self.img_size = img_size
        self.conf_thresh = conf_thresh
    def _preprocess(self, img_path):
        img = cv2.imread(img_path)
        if img is None:
            raise FileNotFoundError(img_path)
        img = cv2.resize(img, (self.img_size[1], self.img_size[0]))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype('float32')/255.0
        img = np.transpose(img, (2,0,1))[None,...]
        return img
    def _postprocess(self, out):
        # Expect model to output N x 6: x1,y1,x2,y2,conf,cls
        boxes=[]
        try:
            arr = out if isinstance(out, (list,tuple)) else [out]
            out0 = arr[0]
            for row in out0:
                x1,y1,x2,y2,conf,cls = row[0],row[1],row[2],row[3],row[4],row[5]
                if conf < self.conf_thresh: continue
                boxes.append({'cls':str(int(cls)),'bbox':[float(x1),float(y1),float(x2),float(y2)],'conf':float(conf)})
        except Exception:
            pass
        return boxes
    def predict(self, image_path):
        inp = self._preprocess(image_path)
        name = self.session.get_inputs()[0].name
        outs = self.session.run(None, {name: inp})
        return self._postprocess(outs[0])
