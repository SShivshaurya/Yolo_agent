import os, zipfile, uuid, json, time
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, Response
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from .db import init_db, get_db
from .models import Base, ModelEntry, DatasetEntry, EvalRun, DriftEntry
from .inference import ModelWrapper
from .evaluator import compute_map
app = FastAPI(title='YOLO Staging Server')
app.mount('/static', StaticFiles(directory='static'), name='static')
DATA_DIR = './data'
EVAL_DIR = './evaluations'
os.makedirs(DATA_DIR, exist_ok=True); os.makedirs(EVAL_DIR, exist_ok=True)
init_db(Base)
from sqlalchemy.orm import Session
from .db import SessionLocal
def get_session():
    s = SessionLocal();
    try: yield s
    finally: s.close()
@app.post('/models/upload')
async def upload_model(name: str = Form(...), version: str = Form(...), file: UploadFile = File(...), db: Session = Depends(get_session)):
    contents = await file.read()
    mdir = os.path.join(DATA_DIR, 'models')
    os.makedirs(mdir, exist_ok=True)
    fname = f"{name}__{version}__{uuid.uuid4().hex}{Path(file.filename).suffix}"
    path = os.path.join(mdir, fname)
    with open(path, 'wb') as f: f.write(contents)
    rec = ModelEntry(name=name, version=version, path=path)
    db.add(rec); db.commit(); db.refresh(rec)
    return {'id': rec.id, 'name': rec.name, 'version': rec.version}
@app.post('/datasets/upload')
async def upload_dataset(name: str = Form(...), file: UploadFile = File(...), db: Session = Depends(get_session)):
    contents = await file.read()
    ddir = os.path.join(DATA_DIR, 'datasets', uuid.uuid4().hex)
    os.makedirs(ddir, exist_ok=True)
    zpath = os.path.join(ddir, file.filename)
    with open(zpath, 'wb') as f: f.write(contents)
    try:
        with zipfile.ZipFile(zpath, 'r') as z: z.extractall(ddir)
    except Exception:
        pass
    rec = DatasetEntry(name=name, path=ddir)
    db.add(rec); db.commit(); db.refresh(rec)
    return {'id': rec.id, 'name': rec.name}
@app.get('/list/models')
def list_models(db: Session = Depends(get_session)):
    recs = db.query(ModelEntry).all()
    return [{'id': r.id, 'name': r.name, 'version': r.version} for r in recs]
@app.get('/list/datasets')
def list_datasets(db: Session = Depends(get_session)):
    recs = db.query(DatasetEntry).all()
    return [{'id': r.id, 'name': r.name} for r in recs]
@app.post('/evaluate')
def evaluate(model_id: int, dataset_id: int, db: Session = Depends(get_session)):
    model = db.query(ModelEntry).get(model_id)
    dataset = db.query(DatasetEntry).get(dataset_id)
    if not model or not dataset:
        raise HTTPException(status_code=404, detail='model/dataset not found')
    mw = ModelWrapper(model.path)
    img_folder = os.path.join(dataset.path, 'images')
    if not os.path.exists(img_folder): img_folder = dataset.path
    imgs = list(Path(img_folder).glob('**/*'))
    preds = []; gts = []; classes = set()
    for p in imgs:
        if p.suffix.lower() not in ['.jpg','.jpeg','.png']: continue
        try:
            dets = mw.predict(str(p))
        except Exception:
            dets = []
        preds.append(dets)
        lab = Path(dataset.path) / 'labels' / (p.stem + '.txt')
        gt = []
        if lab.exists():
            for line in open(lab):
                toks = line.strip().split()
                if len(toks) >= 5:
                    cls = toks[0]; x1,y1,x2,y2 = map(float, toks[1:5])
                    gt.append({'cls': cls, 'bbox': [x1,y1,x2,y2]}); classes.add(cls)
        gts.append(gt)
    metrics = compute_map(preds, gts, list(classes))
    # save evaluation JSON
    ts = int(time.time())
    fname = f"evaluation_model_{model.id}_ds_{dataset.id}_{ts}.json"
    fpath = os.path.join(EVAL_DIR, fname)
    with open(fpath, 'w') as ef: json.dump({'model': {'id': model.id, 'name': model.name, 'version': model.version}, 'dataset': {'id': dataset.id, 'path': dataset.path}, 'metrics': metrics}, ef, indent=2)
    # persist DB record
    er = EvalRun(model_id=model.id, dataset_id=dataset.id, metrics=metrics, json_path=fpath)
    db.add(er); db.commit(); db.refresh(er)
    return {'eval_id': er.id, 'metrics': metrics, 'json': fpath}
@app.post('/compare')
def compare(prev_model: int, curr_model: int, dataset_id: int, db: Session = Depends(get_session)):
    pm = db.query(ModelEntry).get(prev_model)
    cm = db.query(ModelEntry).get(curr_model)
    ds = db.query(DatasetEntry).get(dataset_id)
    if not pm or not cm or not ds:
        raise HTTPException(status_code=404, detail='missing')
    mw_prev = ModelWrapper(pm.path); mw_curr = ModelWrapper(cm.path)
    img_folder = os.path.join(ds.path, 'images')
    if not os.path.exists(img_folder): img_folder = ds.path
    imgs = list(Path(img_folder).glob('**/*'))
    preds_prev=[]; preds_curr=[]; gts=[]; classes=set()
    for p in imgs:
        if p.suffix.lower() not in ['.jpg','.jpeg','.png']: continue
        try: preds_prev.append(mw_prev.predict(str(p)))
        except: preds_prev.append([])
        try: preds_curr.append(mw_curr.predict(str(p)))
        except: preds_curr.append([])
        lab = Path(ds.path)/'labels'/(p.stem+'.txt')
        gt=[]
        if lab.exists():
            for line in open(lab):
                toks=line.strip().split(); cls=toks[0]; x1,y1,x2,y2=map(float,toks[1:5]); gt.append({'cls':cls,'bbox':[x1,y1,x2,y2]}); classes.add(cls)
        gts.append(gt)
    mprev = compute_map(preds_prev, gts, list(classes))
    mcurr = compute_map(preds_curr, gts, list(classes))
    delta = mcurr.get('map_50',0.0) - mprev.get('map_50',0.0)
    ts = int(time.time()); fname = f"compare_{pm.id}_{cm.id}_{ts}.json"; fpath = os.path.join(EVAL_DIR, fname)
    with open(fpath,'w') as ef: json.dump({'prev':mprev,'curr':mcurr,'delta':delta}, ef, indent=2)
    dr = DriftEntry(prev_model_id=pm.id, curr_model_id=cm.id, dataset_id=ds.id, drift=str(delta), json_path=fpath)
    db.add(dr); db.commit(); db.refresh(dr)
    return {'prev': mprev, 'curr': mcurr, 'delta': delta, 'json': fpath}
@app.get('/evaluations/list')
def list_evals():
    files = [f for f in os.listdir(EVAL_DIR) if f.endswith('.json')]
    return files
@app.get('/evaluations/get')
def get_eval(path: str):
    p = os.path.join(EVAL_DIR, path)
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail='not found')
    return json.load(open(p))
@app.get('/metrics')
def metrics():
    return {'status':'ok'}
