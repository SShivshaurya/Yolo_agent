from .utils import match_detections
def compute_map(preds, gts, classes):
    results={}
    for c in classes:
        r = _compute_for_class(preds,gts,c)
        results[c]=r
    map50 = float(sum([results[c]['ap'] for c in results]) / max(1,len(results)))
    return {'per_class': results, 'map_50': map50}
def _compute_for_class(preds,gts,cls):
    scores=[]; truths=[]
    total_gts = sum([len([g for g in gg if g.get('cls')==cls]) for gg in gts])
    for p,gg in zip(preds,gts):
        preds_c = [x for x in p if x.get('cls')==cls]
        gts_c = [x for x in gg if x.get('cls')==cls]
        matches, fns = match_detections(preds_c, gts_c, 0.5)
        for (pd,gt,_iou) in matches:
            scores.append(pd.get('conf',0.0)); truths.append(1 if gt else 0)
    if not scores:
        return {'ap':0.0,'precision':0.0,'recall':0.0}
    order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
    tp=0; fp=0; prec=[]; rec=[]
    for i in order:
        if truths[i]==1: tp+=1
        else: fp+=1
        prec.append(tp/(tp+fp)); rec.append(tp/(total_gts+1e-9))
    ap=0.0; prev_r=0.0
    for p,r in zip(prec,rec):
        ap += p*(r-prev_r); prev_r=r
    return {'ap':ap, 'precision': prec[-1] if prec else 0.0, 'recall': rec[-1] if rec else 0.0}
