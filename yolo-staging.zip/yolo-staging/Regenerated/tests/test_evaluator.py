from app.evaluator import compute_map

def test_map_empty():
    res = compute_map([], [], [])
    assert 'map_50' in res
