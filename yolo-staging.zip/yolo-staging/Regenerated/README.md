# YOLO Staging Server (Non-Docker, Regenerated)

This repository provides a complete local staging server and dashboard for comparing YOLO models.
It supports:
- Uploading models (.onnx, .trt)
- Uploading datasets (ZIP with images/ and labels/ in YOLO txt format)
- Running evaluation (simplified mAP@0.5)
- Comparing two models on a dataset and computing drift
- Saving evaluation JSONs into `evaluations/`
- Simple frontend to upload/list models & datasets and run evaluations + Chart.js visualization

Run locally:
```
python -m venv venv
source venv/bin/activate   # or venv\Scripts\activate on Windows
pip install -r requirements.txt
python app/main.py
```

Open http://localhost:8000/static/index.html
