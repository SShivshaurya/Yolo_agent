async function uploadModel(){
  const form = document.getElementById('fm_model'); const fd = new FormData(form);
  const res = await fetch('/models/upload',{method:'POST', body: fd}); const j = await res.json(); alert('Uploaded model id: '+j.id); loadLists();
}
async function uploadDataset(){
  const form = document.getElementById('fm_data'); const fd = new FormData(form);
  const res = await fetch('/datasets/upload',{method:'POST', body: fd}); const j = await res.json(); alert('Uploaded dataset id: '+j.id); loadLists();
}
async function loadLists(){
  const ms = await fetch('/list/models').then(r=>r.json()); const ds = await fetch('/list/datasets').then(r=>r.json());
  const ml = document.getElementById('model_list'); ml.innerHTML = '';
  ms.forEach(m=> ml.innerHTML += `<li>${m.id} - ${m.name} (${m.version})</li>`);
  const dl = document.getElementById('dataset_list'); dl.innerHTML = '';
  ds.forEach(d=> dl.innerHTML += `<li>${d.id} - ${d.name}</li>`);
}
async function runEvaluate(){
  const model_id = document.getElementById('eval_model').value; const dataset_id = document.getElementById('eval_dataset').value;
  const res = await fetch(`/evaluate?model_id=${model_id}&dataset_id=${dataset_id}`,{method:'POST'}).then(r=>r.json());
  alert('Eval done. mAP@50='+res.metrics.map_50);
  // update chart
  const chartData = [res.metrics.map_50]; window.mapChart.data.labels = ['Model '+model_id]; window.mapChart.data.datasets[0].data = chartData; window.mapChart.update();
}
async function runCompare(){
  const prev = document.getElementById('cmp_prev').value; const curr = document.getElementById('cmp_curr').value; const ds = document.getElementById('cmp_ds').value;
  const res = await fetch(`/compare?prev_model=${prev}&curr_model=${curr}&dataset_id=${ds}`,{method:'POST'}).then(r=>r.json());
  alert('Compare done. delta mAP='+res.delta);
  window.mapChart.data.labels = ['Prev','Curr']; window.mapChart.data.datasets[0].data = [res.prev.map_50, res.curr.map_50]; window.mapChart.update();
}
window.addEventListener('load', ()=>{
  loadLists();
  const ctx = document.getElementById('mapChart').getContext('2d');
  window.mapChart = new Chart(ctx, {type:'bar', data:{labels:['--'], datasets:[{label:'mAP@50', data:[0]}]}});
});
